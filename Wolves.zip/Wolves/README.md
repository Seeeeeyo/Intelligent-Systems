How to use the wolves package.

While you are free to import the package into your favorite IDE, this guide only tells you how to work from the command line.

You can compile and start from inside of the wolves directory, as follows:

javac WolvesApp.java
java WolvesApp

Your own Wolves.Wolf implementations should be added to the same directory and implemented as part of the wolves directory to guarantee that the App can find them.

You only need to adapt the Wolves.java file to (i) make it you your own Wolves.Wolf classes and (ii) to select between limited or unlimited wolf movement.
